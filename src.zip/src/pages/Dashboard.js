import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/navbar';
import Footer from '../components/Footer';
import './Dashboard.css';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [recommendedServices, setRecommendedServices] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch user data (mock API call)
    const fetchUserData = async () => {
      try {
        const res = await fetch('/api/user', { credentials: 'include' });
        const data = await res.json();
        if (res.ok) setUser(data);
      } catch (err) {
        console.error('Error fetching user:', err);
      }
    };

    // Fetch appointments (mock data)
    setAppointments([
      { id: 1, service: 'Haircut', stylist: 'Alex', date: '2023-11-15 14:00', status: 'confirmed' },
      { id: 2, service: 'Beard Trim', stylist: 'Jordan', date: '2023-11-20 11:30', status: 'upcoming' }
    ]);

    // Fetch recommended services (mock data)
    setRecommendedServices([
      { id: 1, name: 'Scalp Treatment', description: 'Nourishing treatment for dry scalp', price: '₹699' },
      { id: 2, name: 'Hot Towel Shave', description: 'Classic barber experience', price: '₹499' }
    ]);

    fetchUserData();
  }, []);

  const handleServiceBook = (serviceId) => {
    navigate(`/booking?service=${serviceId}`);
  };

  const handleReschedule = (appointmentId) => {
    navigate(`/reschedule/${appointmentId}`);
  };

  return (
    <div className="dashboard-page">
      <Navbar />
      
      {/* Personalized Greeting */}
      <section className="user-greeting">
        <h1>Welcome back, {user?.name || 'Guest'}!</h1>
        <p>Your next appointment is in <strong>3 days</strong></p>
      </section>

      {/* Quick Actions */}
      <section className="quick-actions-section">
        <h2>Quick Actions</h2>
        <div className="action-grid">
          <button className="action-card" onClick={() => navigate('/booking')}>
            <span className="action-icon">➕</span>
            <span>Book New Service</span>
          </button>
          <button className="action-card" onClick={() => navigate('/appointments')}>
            <span className="action-icon">📅</span>
            <span>View Appointments</span>
          </button>
          <button className="action-card" onClick={() => navigate('/profile')}>
            <span className="action-icon">👤</span>
            <span>Edit Profile</span>
          </button>
        </div>
      </section>

      {/* Upcoming Appointments */}
      <section className="appointments-section">
        <h2>Your Appointments</h2>
        <div className="appointments-list">
          {appointments.length > 0 ? (
            appointments.map(app => (
              <div key={app.id} className="appointment-card">
                <div className="appointment-info">
                  <h3>{app.service}</h3>
                  <p>With {app.stylist}</p>
                  <p>{new Date(app.date).toLocaleString()}</p>
                  <span className={`status-badge ${app.status}`}>{app.status}</span>
                </div>
                <button 
                  className="reschedule-btn"
                  onClick={() => handleReschedule(app.id)}
                >
                  Reschedule
                </button>
              </div>
            ))
          ) : (
            <p>No upcoming appointments. <a href="/booking">Book now!</a></p>
          )}
        </div>
      </section>

      {/* Recommended Services */}
      <section className="recommended-section">
        <h2>Recommended For You</h2>
        <div className="services-grid">
          {recommendedServices.map(service => (
            <div key={service.id} className="service-card">
              <h3>{service.name}</h3>
              <p>{service.description}</p>
              <div className="service-footer">
                <span className="price">{service.price}</span>
                <button 
                  className="book-btn"
                  onClick={() => handleServiceBook(service.id)}
                >
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Loyalty Points */}
      <section className="loyalty-section">
        <h2>Your Rewards</h2>
        <div className="loyalty-card">
          <div className="points-display">
            <span className="points">150</span>
            <span className="points-label">Points</span>
          </div>
          <p>Earn 50 more points for a free haircut!</p>
          <button className="redeem-btn">View Rewards</button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Dashboard;