import React, { useState } from 'react';
import Navbar from '../components/navbar';
import Footer from '../components/Footer';
import './Artists.css';

const Artists = () => {
  const [selectedArtist, setSelectedArtist] = useState(null);

  const artists = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Senior Stylist",
      experience: "8 years",
      specialties: ["Hair Coloring", "Balayage", "Haircuts"],
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
      rating: 4.9,
      reviews: 127,
      description: "Sarah is our lead color specialist with expertise in modern balayage and creative hair coloring techniques.",
      availability: "Mon-Sat"
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Master Barber",
      experience: "12 years",
      specialties: ["Beard Trimming", "Classic Cuts", "Fades"],
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
      rating: 4.8,
      reviews: 89,
      description: "Michael specializes in classic barbering techniques and modern fade styles for men.",
      availability: "Tue-Sat"
    },
    {
      id: 3,
      name: "Emma Rodriguez",
      role: "Styling Specialist",
      experience: "6 years",
      specialties: ["Wedding Hair", "Updos", "Styling"],
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      rating: 4.9,
      reviews: 156,
      description: "Emma is our go-to stylist for special occasions and wedding hair styling.",
      availability: "Wed-Sun"
    },
    {
      id: 4,
      name: "David Thompson",
      role: "Hair Treatment Expert",
      experience: "10 years",
      specialties: ["Hair Treatments", "Keratin", "Hair Health"],
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      rating: 4.7,
      reviews: 73,
      description: "David focuses on hair health and treatments, specializing in keratin and deep conditioning.",
      availability: "Mon-Fri"
    },
    {
      id: 5,
      name: "Lisa Park",
      role: "Junior Stylist",
      experience: "3 years",
      specialties: ["Haircuts", "Styling", "Color Touch-ups"],
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=688&q=80",
      rating: 4.6,
      reviews: 45,
      description: "Lisa brings fresh perspectives and modern techniques to our salon team.",
      availability: "Thu-Sun"
    },
    {
      id: 6,
      name: "James Wilson",
      role: "Beard Specialist",
      experience: "7 years",
      specialties: ["Beard Grooming", "Mustache Styling", "Beard Treatments"],
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
      rating: 4.8,
      reviews: 92,
      description: "James is our beard grooming expert, specializing in beard shaping and maintenance.",
      availability: "Mon-Sat"
    }
  ];

  const handleArtistClick = (artist) => {
    setSelectedArtist(artist);
  };

  const closeModal = () => {
    setSelectedArtist(null);
  };

  return (
    <>
      <Navbar />
      <div className="artists-container">
        {/* Hero Section */}
        <div className="artists-hero">
          <div className="hero-content">
            <h1>Meet Our Artists</h1>
            <p>Talented professionals dedicated to making you look and feel your best</p>
          </div>
        </div>

        {/* Artists Grid */}
        <div className="artists-grid">
          {artists.map((artist) => (
            <div key={artist.id} className="artist-card" onClick={() => handleArtistClick(artist)}>
              <div className="artist-image">
                <img src={artist.image} alt={artist.name} />
                <div className="artist-overlay">
                  <span className="view-profile">View Profile</span>
                </div>
              </div>
              <div className="artist-info">
                <h3>{artist.name}</h3>
                <p className="artist-role">{artist.role}</p>
                <div className="artist-rating">
                  <span className="stars">★★★★★</span>
                  <span className="rating-text">{artist.rating} ({artist.reviews} reviews)</span>
                </div>
                <div className="artist-specialties">
                  {artist.specialties.map((specialty, index) => (
                    <span key={index} className="specialty-tag">{specialty}</span>
                  ))}
                </div>
                <p className="artist-experience">{artist.experience} experience</p>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="artists-stats">
          <div className="stat-item">
            <h3>6</h3>
            <p>Professional Artists</p>
          </div>
          <div className="stat-item">
            <h3>50+</h3>
            <p>Years Combined Experience</p>
          </div>
          <div className="stat-item">
            <h3>1000+</h3>
            <p>Happy Clients</p>
          </div>
          <div className="stat-item">
            <h3>4.8</h3>
            <p>Average Rating</p>
          </div>
        </div>

        {/* Modal for Artist Details */}
        {selectedArtist && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <button className="modal-close" onClick={closeModal}>×</button>
              <div className="modal-artist">
                <div className="modal-artist-image">
                  <img src={selectedArtist.image} alt={selectedArtist.name} />
                </div>
                <div className="modal-artist-info">
                  <h2>{selectedArtist.name}</h2>
                  <p className="modal-role">{selectedArtist.role}</p>
                  <div className="modal-rating">
                    <span className="stars">★★★★★</span>
                    <span className="rating-text">{selectedArtist.rating} ({selectedArtist.reviews} reviews)</span>
                  </div>
                  <p className="modal-description">{selectedArtist.description}</p>
                  <div className="modal-specialties">
                    <h4>Specialties:</h4>
                    <div className="specialties-list">
                      {selectedArtist.specialties.map((specialty, index) => (
                        <span key={index} className="specialty-tag">{specialty}</span>
                      ))}
                    </div>
                  </div>
                  <div className="modal-details">
                    <div className="detail-item">
                      <strong>Experience:</strong> {selectedArtist.experience}
                    </div>
                    <div className="detail-item">
                      <strong>Availability:</strong> {selectedArtist.availability}
                    </div>
                  </div>
                  <button className="book-artist-btn">Book with {selectedArtist.name}</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default Artists; 