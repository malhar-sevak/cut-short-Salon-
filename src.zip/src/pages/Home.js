import React from 'react';
import Navbar from '../components/navbar';
import Footer from '../components/Footer';
import './Home.css';

const Home = () => {
  return (
    <div className="home-page">
      <Navbar />

      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1>Welcome to Cut-Short</h1>
          <p>Where style meets precision - your premium salon experience</p>
          <div className="hero-btns">
            <a href="/signup" className="action-btn primary">Get Started</a>
            <a href="/services" className="action-btn secondary">Our Services</a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section">
        <h2>Our Signature Services</h2>
        <div className="services-grid">
          <div className="service-card">
            <div className="service-icon">✂️</div>
            <h3>Premium Haircut</h3>
            <p>Expert styling tailored to your personality</p>
            <div className="service-price">₹499</div>
          </div>

          <div className="service-card">
            <div className="service-icon">🧴</div>
            <h3>Luxury Facial</h3>
            <p>Rejuvenate your skin with our premium treatment</p>
            <div className="service-price">₹899</div>
          </div>

          <div className="service-card">
            <div className="service-icon">🧔</div>
            <h3>Beard Grooming</h3>
            <p>Precision trimming and conditioning</p>
            <div className="service-price">₹399</div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="section">
        <h2>Why Choose Cut-Short?</h2>
        <div className="quick-actions">
          <div className="action-card">
            <div className="action-icon">👨‍🎨</div>
            <h3>Expert Stylists</h3>
            <p>Certified professionals with 5+ years experience</p>
          </div>
          <div className="action-card">
            <div className="action-icon">🌿</div>
            <h3>Premium Products</h3>
            <p>We use only top-quality, organic products</p>
          </div>
          <div className="action-card">
            <div className="action-icon">✨</div>
            <h3>Hygienic Environment</h3>
            <p>Sanitized tools and clean spaces for your safety</p>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section">
        <h2>Client Experiences</h2>
        <div className="activity-list">
          <div className="activity-item">
            <div className="activity-icon">💇</div>
            <div className="activity-content">
              <h4>"The best haircut I've ever had!"</h4>
              <p>The stylist understood exactly what I wanted</p>
            </div>
            <div className="activity-status completed">Verified</div>
          </div>
          <div className="activity-item">
            <div className="activity-icon">🧖</div>
            <div className="activity-content">
              <h4>"Amazing facial treatment"</h4>
              <p>My skin has never felt better!</p>
            </div>
            <div className="activity-status completed">Verified</div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section cta-section">
        <h2>Ready for Your Transformation?</h2>
        <p>Book your appointment today and experience the Cut-Short difference</p>
        <div className="cta-btns">
          <a href="/booking" className="action-btn primary">Book Now</a>
          <a href="/contact" className="action-btn secondary">Contact Us</a>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;