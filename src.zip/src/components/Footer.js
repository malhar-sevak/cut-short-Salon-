import React from 'react';
import './Layout.css';

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; {new Date().getFullYear()} Cut-Short Salon. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
