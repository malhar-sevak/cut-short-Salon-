    import React, { useState, useEffect } from 'react';
import './Carousel.css';

const slides = [
  {
    image: 'https://i.imgur.com/ViR8OvP.jpg',
    caption: 'Get 20% off on Haircuts this week!',
  },
  {
    image: 'https://i.imgur.com/k1hZtGz.jpg',
    caption: 'Glow Up! Book a facial now.',
  },
  {
    image: 'https://i.imgur.com/FkZTl0q.jpg',
    caption: 'Meet our Top Stylists of the Month!',
  },
];

const Carousel = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="carousel">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`carousel-slide ${index === current ? 'active' : ''}`}
        >
          <img src={slide.image} alt={`slide-${index}`} />
          <div className="carousel-caption">{slide.caption}</div>
        </div>
      ))}
    </div>
  );
};

export default Carousel;
