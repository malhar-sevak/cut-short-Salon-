import React, { useState, useEffect } from 'react';
import './Layout.css';

const Navbar = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/user', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        }
      } catch (error) {
        console.error('Auth check error:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  return (
    <nav className="navbar">
      <div className="navbar-logo">💇‍♂️ Cut-Short</div>
      <div className="navbar-links">
        {user ? (
          <>
            <a href="/dashboard">Dashboard</a>
            <a href="/artists">Artists</a>
            <span className="user-welcome">Welcome, {user.name}!</span>
            <a href="/home">Logout</a>
          </>
        ) : (
          <>
            <a href="/artists">Artists</a>
            <a href="/login">Login</a>
            <a href="/signup">Signup</a>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
